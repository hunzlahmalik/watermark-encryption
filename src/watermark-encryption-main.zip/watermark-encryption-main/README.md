# watermark-encryption
Watermarking of chest CT scan medical images for content authentication. Paper implementation in MATLAB.
