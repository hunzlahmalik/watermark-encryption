function str = im2str(inputimg)
    str = mat2str(inputimg(:));
end
